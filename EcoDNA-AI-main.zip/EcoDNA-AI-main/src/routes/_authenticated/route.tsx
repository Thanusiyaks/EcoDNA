import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { LocationProvider } from "@/lib/eco/location-store";
import { VirtualProvider } from "@/lib/eco/virtual-store";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: () => (
    <LocationProvider>
      <VirtualProvider>
        <Outlet />
      </VirtualProvider>
    </LocationProvider>
  ),
});
